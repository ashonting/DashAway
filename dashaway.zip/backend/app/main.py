from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import engine, Base
from app.routes import analysis, auth, users, history, stats, paddle

Base.metadata.create_all(bind=engine)

app = FastAPI()

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(analysis.router, prefix="/api")
app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
app.include_router(users.router, prefix="/api/users", tags=["users"])
app.include_router(history.router, prefix="/api/history", tags=["history"])
app.include_router(stats.router, prefix="/api/stats", tags=["stats"])
print("Stats router included in main.py!")

app.include_router(paddle.router, prefix="/api/paddle", tags=["paddle"])

@app.get("/")
def read_root():
    return {"message": "DashAway Backend is running"}

@app.get("/hello")
def hello_world():
    return {"message": "Hello from FastAPI!"}
