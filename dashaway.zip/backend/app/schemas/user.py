from pydantic import BaseModel
from typing import List
from .subscription import Subscription

class UserBase(BaseModel):
    email: str

class UserCreate(UserBase):
    password: str

class UserPasswordUpdate(BaseModel):
    password: str

class User(UserBase):
    id: int
    is_active: bool
    usage_count: int
    # subscriptions: list[Subscription] = []

    class Config:
        orm_mode = True
