from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.services.segmenter import segment_text
from app.models.stats import GlobalStats
from app.models.history import DocumentHistory
from app.auth.auth import get_current_user
from app.models.user import User

router = APIRouter()

class TextProcessRequest(BaseModel):
    text: str

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/process")
def process_text_endpoint(
    request: TextProcessRequest, 
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user) # Optional for now
):
    try:
        result = segment_text(request.text)
        
        # Increment global stats
        stats = db.query(GlobalStats).first()
        if not stats:
            stats = GlobalStats()
            db.add(stats)
        
        stats.total_texts_cleaned += 1
        stats.total_em_dashes_found += len([s for s in result['segments'] if s['type'] == 'em_dash'])
        stats.total_cliches_found += len([s for s in result['segments'] if s['type'] == 'cliche'])
        stats.total_jargon_found += len([s for s in result['segments'] if s['type'] == 'jargon'])
        stats.total_ai_tells_found += len([s for s in result['segments'] if s['type'] == 'ai_tell'])
        stats.total_documents_processed += 1
        
        # Save history for paid users (logic to check for paid status to be added)
        if current_user: # and current_user.is_paid:
            history_entry = DocumentHistory(
                user_id=current_user.id,
                title=request.text[:50], # First 50 chars as title
                content=request.text,
                analysis_results=result
            )
            db.add(history_entry)
            
            # Decrement free user usage count
            if current_user.usage_count > 0:
                current_user.usage_count -= 1

        db.commit()
        
        return result
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
