from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import schemas
from app.auth import auth
from app.database import SessionLocal
from app.models.user import User
from app.schemas.user import UserPasswordUpdate

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/me", response_model=schemas.user.User)
def read_users_me(current_user: User = Depends(auth.get_current_user)):
    return current_user

@router.put("/me/password")
def update_password(
    password_update: UserPasswordUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(auth.get_current_user),
):
    hashed_password = auth.get_password_hash(password_update.password)
    current_user.hashed_password = hashed_password
    db.add(current_user)
    db.commit()
    return {"message": "Password updated successfully"}
