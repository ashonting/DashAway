from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import schemas
from app.database import SessionLocal
from app.models.stats import GlobalStats

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/global", response_model=schemas.stats.GlobalStats)
def read_global_stats(db: Session = Depends(get_db)):
    stats = db.query(GlobalStats).first()
    if not stats:
        stats = GlobalStats()
        db.add(stats)
        db.commit()
        db.refresh(stats)
    return stats
