from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app import schemas
from app.auth import auth
from app.database import SessionLocal
from app.models.history import DocumentHistory
from app.models.user import User

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/", response_model=List[schemas.history.DocumentHistory])
def read_history(current_user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    # In a real app, you'd check if the user has a paid subscription
    # For now, we'll just return the history
    return db.query(DocumentHistory).filter(DocumentHistory.user_id == current_user.id).all()

@router.post("/", response_model=schemas.history.DocumentHistory)
def create_history(history: schemas.history.DocumentHistoryCreate, current_user: User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    db_history = DocumentHistory(**history.dict(), user_id=current_user.id)
    db.add(db_history)
    db.commit()
    db.refresh(db_history)
    return db_history
