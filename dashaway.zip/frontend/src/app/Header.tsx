'use client';

import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import { Sun, Moon } from 'lucide-react'; // Using lucide-react for icons

export default function Header({ toggleTheme, theme }: { toggleTheme: () => void; theme: string }) {
  const { user, logout } = useAuth();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 max-w-screen-2xl items-center justify-between">
        <Link href="/">
          <img src="/logo.png" alt="DashAway Logo" className="h-8 w-auto" />
        </Link>
        <div className="flex items-center gap-4">
          <nav className="flex items-center gap-4 text-sm">
            {user ? (
              <>
                <Link href="/dashboard" className="transition-colors hover:text-foreground/80 text-foreground/60">Dashboard</Link>
                <button onClick={logout} className="transition-colors hover:text-foreground/80 text-foreground/60">Log Out</button>
              </>
            ) : (
              <>
                <Link href="/login" className="transition-colors hover:text-foreground/80 text-foreground/60">Login</Link>
                <Link href="/register" className="px-4 py-2 rounded-md bg-primary text-primary-foreground font-medium">Register</Link>
              </>
            )}
          </nav>
          <button onClick={toggleTheme} className="p-2 rounded-full hover:bg-accent">
            {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>
        </div>
      </div>
    </header>
  );
}
