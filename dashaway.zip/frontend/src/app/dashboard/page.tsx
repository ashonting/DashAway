'use client';

import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

import Stats from './Stats';
import History from './History';

export default function DashboardPage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [user, loading, router]);

  if (loading || !user) {
    return <div>Loading...</div>;
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-12">Welcome, {user.email}!</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-bold mb-4">Your Stats</h2>
          <Stats />
        </div>
        <div>
          <h2 className="text-2xl font-bold mb-4">Document History</h2>
          <History />
        </div>
      </div>
      
      <div className="mt-8">
        <h2 className="text-2xl font-bold mb-4">Account</h2>
        <p>Your current plan: {user.subscriptions && user.subscriptions.some(s => s.status === 'active') ? 'Plus' : 'Free'}</p>
        <p>Remaining uses: {user.usage_count}</p>
        {/* Link to account management page */}
      </div>
    </main>
  );
}
